"""Validated real project work for task 1."""
TASK_STAGE = 1
