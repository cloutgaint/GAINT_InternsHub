# Fake News Detection System – Smart City Services Variant

Technology: Python

Use `START_PROJECT.bat` for the local project presentation. Read `STUDENT_PROJECT_GUIDE.md` before Task 1.
