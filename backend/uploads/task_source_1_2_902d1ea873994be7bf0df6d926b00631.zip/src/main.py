from pathlib import Path
import sqlite3

def main():
    db = Path(__file__).parents[1] / 'database' / 'local.db'
    with sqlite3.connect(db) as connection:
        count = connection.execute('SELECT COUNT(*) FROM demo_records').fetchone()[0]
    print('Fake News Detection System – Smart City Services Variant')
    print(f'Local database ready: {count} demo records')

if __name__ == '__main__':
    main()
