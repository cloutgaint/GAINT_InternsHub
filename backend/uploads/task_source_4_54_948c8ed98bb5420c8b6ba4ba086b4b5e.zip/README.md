export const taskStage = 1;
